package com.example.magspace.LevelSecond;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.magspace.Base.BaseActivity;
import com.example.magspace.Base.BasePageActivity;
import com.example.magspace.R;

public class Cylinder3 extends BasePageActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setcontentlayout(R.layout.activity_cylinder3);
        ChangSubtileColor(R.color.colorblue);
        init("探险","","用MAGSPACE制作柱体");
        setmPageNumber("03/06");
    }
}
