package com.example.magspace.Bean;

public class Item {

    public String title;
    public int image;

    public Item(String title, int image) {
        this.title = title;
        this.image = image;
    }
}
