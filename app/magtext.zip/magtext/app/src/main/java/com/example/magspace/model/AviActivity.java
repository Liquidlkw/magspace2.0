package com.example.magspace.model;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.widget.GridLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.magspace.Base.BaseActivity;
import com.example.magspace.Bean.AviBean;
import com.example.magspace.Bean.BuildingBean;
import com.example.magspace.R;
import com.example.magspace.Utils.DataUtil;
import com.example.magspace.Utils.ToastUtil;
import com.example.magspace.adapter.AviAdapter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AviActivity extends BaseActivity {

    private RecyclerView mRv;
    public   static List<AviBean> list;
    private ProgressDialog dialog;
    private AviAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        if (DataUtil.ismusicplay) {
            DataUtil.backmusic.pause();
//            DataUtil.ismusicplay = false;
        }
        setContentLayout(R.layout.activity_avi);
        setTitle("视频展示");
        dialog = ProgressDialog.show(this, "提示", "正在加载中", false);
        initdata();
    }
    protected void onResume() {
        super.onResume();
        if(DataUtil.ismusicplay&&DataUtil.backmusic!=null)
            DataUtil.backmusic.pause();
    }
    private void postDataWithParam() {

        OkHttpClient client = new OkHttpClient();//创建OkHttpClient对象。
        FormBody.Builder formBody = new FormBody.Builder();//创建表单请求体
        Request request = new Request.Builder()//创建Request 对象。
                .url("http://android.magspace2015.com/magspace/android_avi_list")
                .post(formBody.build())//传递请求体
                .build();
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(Call call, IOException e) {
                ToastUtil.getInstance().showToast("请检查您的网络设置");
                dialog.dismiss();
                finish();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()) {
                    Log.d("okhttp","获取数据成功");
                    String string = response.body().string();
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject(string);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String jsonstring = null;
                    try {
                        jsonstring = jsonObject.getString("data");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.i("jsonArraystring", "parseNetworkResponse: "+jsonstring);
                    Gson gson = new Gson();
                    list =  new ArrayList<>();
                    list = gson.fromJson(jsonstring,new TypeToken<List<AviBean>>(){}.getType());
                    Log.i("list1", "initView: "+list.size());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            initView();
                        }
                    });

                    dialog.dismiss();

                }else{
                    Log.d("okhttp","获取数据失败");
                    ToastUtil.getInstance().showToast("获取数据失败");
                    dialog.dismiss();

                }
            }
        });

    }

    private void initdata() {
        postDataWithParam();
//        adapter.notifyDataSetChanged();
    }

    private void initView() {
        mRv = (RecyclerView) findViewById(R.id.rv);
        mRv.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new AviAdapter(list);
//        Log.i("list", "initView: "+list.size());
        mRv.setAdapter(adapter);

//        adapter.notifyDataSetChanged();

    }
}


