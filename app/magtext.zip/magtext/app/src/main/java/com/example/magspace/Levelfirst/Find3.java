package com.example.magspace.Levelfirst;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.magspace.Base.BasePageActivity;
import com.example.magspace.R;

public class Find3 extends BasePageActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setcontentlayout(R.layout.activity_find3);
        init("探险","","使用MAGSPACE制作一个模式火车");
        setmPageNumber("03/06");
    }
}
