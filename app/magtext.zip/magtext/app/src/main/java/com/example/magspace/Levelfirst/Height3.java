package com.example.magspace.Levelfirst;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.example.magspace.Base.BasePageActivity;
import com.example.magspace.R;

public class Height3 extends BasePageActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setcontentlayout(R.layout.activity_height3);
        init("探险","","利用MAGSPACE比较塔的高度");
        setmPageNumber("03/06");

    }

}
