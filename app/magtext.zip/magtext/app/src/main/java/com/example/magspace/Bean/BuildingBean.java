package com.example.magspace.Bean;

public class BuildingBean {
    public int id;
    public String title;
    public String logo;
    public String logosetting;
    public String gif;

    public BuildingBean(int id, String title, String logo, String logosetting, String gif) {
        this.id = id;
        this.title = title;
        this.logo = logo;
        this.logosetting = logosetting;
        this.gif = gif;
    }
}
