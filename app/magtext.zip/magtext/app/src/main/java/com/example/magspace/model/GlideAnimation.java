package com.example.magspace.model;

class GlideAnimation<T> {
}
