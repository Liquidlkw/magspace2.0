package com.example.magspace.model;

class GlideDrawable {
}
