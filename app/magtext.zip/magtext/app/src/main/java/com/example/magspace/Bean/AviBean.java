package com.example.magspace.Bean;

public class AviBean {
    public int id;
    public String pic;
    public String title;
    public String avi;
    public  String describe;

    public AviBean(int id, String pic, String title, String avi, String describe) {
        this.id = id;
        this.pic = pic;
        this.title = title;
        this.avi = avi;
        this.describe = describe;
    }
}
