package com.example.magspace.Bean;

public class ProudctionBean {
    public int id;
    public String title;
    public String pic;

    public ProudctionBean(int id, String title, String pic) {
        this.id = id;
        this.title = title;
        this.pic = pic;
    }
}
